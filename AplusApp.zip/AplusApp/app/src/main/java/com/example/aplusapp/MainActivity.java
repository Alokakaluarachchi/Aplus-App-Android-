package com.example.aplusapp;

import android.app.Activity;

public class MainActivity extends Activity {
}
